module Parser =
  functor (G : Graph.Sig.G) ->
    functor (Ls : Sig.DrawableLabels with type v = G.V.label and type e = G.E.label) ->
      functor (DotParser : sig val parse: string -> G.t end) ->
	struct
	  let parse file = DotParser.parse file;;
	end

module DrawableGraph =
  functor (G : Graph.Sig.G) ->
    functor (Labeler : Sig.DrawableLabels with type v = G.V.label and type e = G.E.label) ->
      struct
	include G;;
	include Labeler;;
      end
