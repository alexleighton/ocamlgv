open Cairotools
open Types

let paint_nodes context nodelist =
	let aux = function Node(ctrpt,label) ->
		rounded_rectangle context ctrpt 25.0 10.0 3.0 1.0;
		draw_string context ctrpt label
	in
	List.iter aux nodelist

let paint_edges context edgelist =
	let aux = function Edge(plist,label,iscurve) ->
		if (iscurve)
		then curved_line context plist 1.0
		else straight_line context plist 1.0
	in
	List.iter aux edgelist

let paint_image = function Image(w,h,nlist,elist) ->
	let surface = create_surface w h in
	let ctx = get_context surface in
	fill_surface ctx (Color(1.0,1.0,1.0)) ;
	paint_edges ctx elist ;
	paint_nodes ctx nlist ;
	surface
