(**************************************************************************)
(*                                                                        *)
(*  Ocamlgv: a native graph visualization library for OCaml               *)
(*  Copyright (C) 2008  Alex Leighton                                     *)
(*                                                                        *)
(*  OCamlgv is free software: you can redistribute it and/or modify       *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation, either version 3 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  This program is distributed in the hope that it will be useful,       *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(**************************************************************************)

(* TESTING

(** Main testing file for ocamlgv. *)

open Graph.Pack.Graph;;

(** The file to parse. *)
let file = "test/test.dot";;
let out = "test/testout.dot";;

let output graph = dot_output graph out;;

(** The graph parsed from the dot file 'file'*)
(* let graph = parse_dot_file file;; *)

(** Displays the parsed graph in graphviz *)
let show = display_with_gv;;

(** Main method *)
(* let oldmain = display_with_gv graph ; output graph;; *)

*)
