module type GraphLabel = sig
  type v;;
  val toStringV: v -> string;;
  type e;;
  val toStringE: e -> string;;
end
