(* open Draw;; *)

let width  = 400
let height = 400

let drawScene w =
	let surface = Draw.create_surface width height in
	let ctx = Draw.get_context surface in
	let point1 = Draw.Point(200.,100.) in
	let point2 = Draw.Point(300.,300.) in
	let point3 = Draw.Point(100.,300.) in
	let point4 = Draw.Point(200.,50. ) in
	let color  = Draw.Color(0.95,0.95,0.95) in
		Draw.set_background ctx color ;
		Draw.draw_polygon ctx (point1::point2::point3::[]) w ;
		Draw.draw_line ctx point1 point4 w ;
		surface

let main =
	for i = 1 to 15 do
		let surface = drawScene (float_of_int i) in
		Draw.save_to_pngfile surface ("triangle" ^ (string_of_int i) ^ ".png")
	done

(*
let main = 
  (* Setup Cairo *)
  let surface = Draw.create_surface width height in
  let ctx = Draw.get_context surface in
  let point1 = {x=200.; y=100.} in
  let point2 = {x=200.; y=50.} in

  (* Set thickness of brush *)
  Cairo.set_line_width ctx 15. ;

  (* Draw out the triangle using absolute coordinates *)
  Cairo.move_to     ctx   200.  100. ;
  Cairo.line_to     ctx   300.  300. ;
  Cairo.rel_line_to ctx (-200.)   0. ;
  Cairo.close_path  ctx ;

  (* Apply the ink *)
  Cairo.stroke ctx ;

  Draw.draw_line ctx point1 point2 2.;

  (* Output a PNG file *)
  Draw.save_to_pngfile surface "triangle.png"
;;

*)
