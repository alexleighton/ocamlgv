(**************************************************************************)
(*                                                                        *)
(*  Ocamlgv: a native graph visualization library for OCaml               *)
(*  Copyright (C) 2008  Alex Leighton                                     *)
(*                                                                        *)
(*  OCamlgv is free software: you can redistribute it and/or modify       *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation, either version 3 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  This program is distributed in the hope that it will be useful,       *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(**************************************************************************)

(** Utility module for creating drawable graphs *)

module MakeDrawableGraph =
  functor (G : Graph.Sig.G) ->
    functor (Labeler : Sig.DrawableLabels with type v = G.V.label and type e = G.E.label) ->
struct
  include G;;
  include Labeler;;
end

module Pack =
struct

  module StringLabeler =
  struct
    type v;;
    let toStringV label:v = label;;
    type e;;
    let toStringE label:e = label;;
  end

  module Generic(G : Graph.Sig.IM with type V.label = string and type E.label = string) = struct

    include G;;
    
    
    
  end

end

(*
module Parse
  (B: Graph.Builder.S)
    (L : sig
     val node : node_id -> attr list -> B.G.V.label
       (** how to build the node label out of the set of attributes *)
     val edge : attr list -> B.G.E.label
       (** how to build the edge label out of the set of attributes *)
   end)
  (Labeler: Sig.DrawableLabels with type v = B.G.V.label and type e = B.G.E.label) =
(Graph.Dot.Parse B L).parse
*)
