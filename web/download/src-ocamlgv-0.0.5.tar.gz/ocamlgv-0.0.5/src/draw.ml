(**************************************************************************)
(*                                                                        *)
(*  Ocamlgv: a native graph visualization library for OCaml               *)
(*  Copyright (C) 2008  Alex Leighton                                     *)
(*                                                                        *)
(*  OCamlgv is free software: you can redistribute it and/or modify       *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation, either version 3 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  This program is distributed in the hope that it will be useful,       *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(**************************************************************************)

(** Module for drawing a graph representation *)

open Cairotools
open Types

(** Paints a list of nodes given a Cairo context.
@param context The Cairo context.
@param nodelist The list of nodes. *)
let paint_nodes context nodelist =
  let aux = function Node(ctrpt,label) ->
    rounded_rectangle context ctrpt 25.0 10.0 3.0 1.0;
    draw_string context ctrpt label
  in
    List.iter aux nodelist

(** Paints a list of edges given a Cairo context.
@param context The Cairo context.
@param edgelist The list of edges. *)
let paint_edges context edgelist =
  let aux = function Edge(plist,label,iscurve) ->
    if (iscurve)
    then curved_line context plist 1.0
    else straight_line context plist 1.0
  in
    List.iter aux edgelist

(** Paints an image.
@param Image The virtual image to paint.
@return the Cairo surface containing the painted image. *)
let paint_image = function Image(w,h,nlist,elist) ->
  let surface = create_surface w h in
  let ctx = get_context surface in
    fill_surface ctx (Color(1.0,1.0,1.0)) ;
    paint_edges ctx elist ;
    paint_nodes ctx nlist ;
    surface
