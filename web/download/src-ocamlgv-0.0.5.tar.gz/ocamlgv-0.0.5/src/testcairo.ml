(**************************************************************************)
(*                                                                        *)
(*  Ocamlgv: a native graph visualization library for OCaml               *)
(*  Copyright (C) 2008  Alex Leighton                                     *)
(*                                                                        *)
(*  OCamlgv is free software: you can redistribute it and/or modify       *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation, either version 3 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  This program is distributed in the hope that it will be useful,       *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(**************************************************************************)

open Cairotools;;
open Types;;
open Draw;;

let width  = 400
let height = 400

let main =
	let w = 200 and h = 200 in
	let n1 = Node(Point(20.0,20.0),"1") in
	let n2 = Node(Point(120.0,120.0),"2") in
	let n3 = Node(Point(120.0,20.0),"3") in
	let n4 = Node(Point(20.0,120.0),"4") in
	let e1 = Edge([Point(20.0,20.0);Point(120.0,120.0)],"",false) in
	let e2 = Edge([Point(120.0,20.0);Point(20.0,120.0)],"",false) in
	let nlist = [n1;n2;n3;n4] in
	let elist = [e1;e2] in
	let img = Image(w,h,nlist,elist) in
	let surface = paint_image img in
	print_endline (string_of_node n1) ;
	print_endline (string_of_node n2) ;
	print_endline (string_of_node n3) ;
	print_endline (string_of_node n4) ;
	print_endline (string_of_nodelist nlist) ;
	print_endline (string_of_edgelist elist) ;
	save_to_pngfile surface "test.png"

(*
let main =
	let surface = create_surface width height in
	let ctx = get_context surface in
	let p  = Point(0.0 ,  0.0)   in
	let p1 = Point(100.0, 0.0)   in
	let p2 = Point(0.0,   100.0) in
	let p3 = Point(100.0, 100.0) in
	let p4 = Point(200.0, 100.0) in
	let p5 = Point(100.0, 200.0) in
	let p6 = Point(200.0, 200.0) in
	let plist = [p;p1;p2;p3;p4;p5;p6] in
	fill_surface ctx (Color(1.0,1.0,1.0)) ;
	curved_line ctx plist 5.0 ;
(*	oval ctx (Point(200.0,200.0)) 60.0 30.0 5.0 ; *)
	rounded_rectangle ctx (Point(140.0,170.0)) 120.0 60.0 10.0 5.0 ;
	save_to_pngfile surface "curve.png"
*)

(*
let main =
	let surface = create_surface width height in
	let ctx = get_context surface in
	let p = Point(25.6,128.0) in
	let p1 = Point(102.4,230.4) in
	let p2 = Point(153.6,25.6)  in
	let p3 = Point(230.4,128.0) in
	let plist = [p;p1;p2;p3] in
	set_background ctx (Color(1.0,1.0,1.0)) ;
	curved_line ctx plist 10.;
	set_color ctx (Color(0.0,0.0,0.7)) ;
	straight_line ctx plist 6.;
	let p4 = Point(200.,200.) in
	set_color ctx (Color(0.0,0.5,0.0)) ;
	rounded_rectangle ctx p4 100. 50. 30. 5.;
	save_to_pngfile surface ("curve.png")

*)
