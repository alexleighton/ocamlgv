(**************************************************************************)
(*                                                                        *)
(*  Ocamlgv: a native graph visualization library for OCaml               *)
(*  Copyright (C) 2008  Alex Leighton                                     *)
(*                                                                        *)
(*  Ocamlgv is free software: you can redistribute it and/or modify       *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation, either version 3 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  This program is distributed in the hope that it will be useful,       *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(**************************************************************************)

(** Module containing types used by other modules *)

(** Point type. Requires float values for x and y. *)
type point = Point of float*float

(** Color type. Requires three float values for the rgb values. *)
type color = Color of float*float*float

let white = Color(1.0,1.0,1.0)
let black = Color(0.0,0.0,0.0)
let red   = Color(1.0,0.0,0.0)
let blue  = Color(0.0,0.0,1.0)
let green = Color(0.0,1.0,0.0)

(** Drawable node type. *)
type node = Node of point * string

(** Drawable edge type. *)
type edge = Edge of point list * string * bool

(** Virtual graph image. Width * Height * nodes * edges *)
type virtual_image = Image of int * int * node list * edge list

let string_of_point = function Point(x,y) ->
"(" ^ (string_of_float x) ^ "," ^ (string_of_float y) ^ ")"

let string_of_color = function Color(r,g,b) ->
"("^(string_of_float r)^","^(string_of_float g)^","^(string_of_float b)^")"

let string_of_node = function Node(p,l) ->
"Node:"^(string_of_point p)^"-\""^l^"\""

let string_of_pointlist plist =
	let return = ref "[" in
	let aux p = return := (!return ^ (string_of_point p) ^ ",") in
	List.iter aux plist ;
	(String.set !return ((String.length !return) - 1) ']') ;
	!return

let string_of_edge = function Edge(plist,l,b) ->
	"Edge:"^(string_of_pointlist plist)^"-\""^l^"\"-"^(string_of_bool b)

let string_of_edgelist elist =
	let return = ref "[" in
	let aux e = return := (!return ^ (string_of_edge e) ^ ",") in
	List.iter aux elist ;
	(String.set !return ((String.length !return) - 1) ']') ;
	!return

let string_of_nodelist nlist = 
	let return = ref "[" in
	let aux n = return := (!return ^ (string_of_node n) ^ ",") in
	List.iter aux nlist ;
	(String.set !return ((String.length !return) - 1) ']') ;
	!return

let string_of_image = function Image(w,h,nlist,elist) ->
	let ns = string_of_nodelist nlist in
	let es = string_of_edgelist elist in
	let wxh = "("^(string_of_int w)^"x"^(string_of_int h)^")" in
	"Image:" ^ wxh ^ " " ^ ns ^ " " ^ es
