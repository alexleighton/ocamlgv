(**************************************************************************)
(*                                                                        *)
(*  Ocamlgv: a native graph visualization library for OCaml               *)
(*  Copyright (C) 2008  Alex Leighton                                     *)
(*                                                                        *)
(*  OCamlgv is free software: you can redistribute it and/or modify       *)
(*  it under the terms of the GNU General Public License as published by  *)
(*  the Free Software Foundation, either version 3 of the License, or     *)
(*  (at your option) any later version.                                   *)
(*                                                                        *)
(*  This program is distributed in the hope that it will be useful,       *)
(*  but WITHOUT ANY WARRANTY; without even the implied warranty of        *)
(*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *)
(*  GNU General Public License for more details.                          *)
(*                                                                        *)
(**************************************************************************)

open Cairotools;;

let width  = 400
let height = 400


let drawScene w =
	let surface = create_surface width height in
	let ctx = get_context surface in
	let point1 = Point(200.,100.) in
	let point2 = Point(300.,300.) in
	let point3 = Point(100.,300.) in
	let point4 = Point(200.,50. ) in
	let color  = Color(0.95,0.95,0.95) in
	let plist = [point1;point2;point3] in
		set_background ctx color ;
		draw_polygon ctx plist w ;
		draw_line ctx point1 point4 w ;
		surface

(*
let drawScene w =
	let surface = create_surface width height in
	let ctx = get_context surface in
	let p = Point(200.,200.) in
		rounded_rectangle ctx p (w*.10.) (w*.10.) w;
		surface
*)

let main =
	for i = 1 to 15 do
		let surface = drawScene (float_of_int i) in
		save_to_pngfile surface ("triangle" ^ (string_of_int i) ^ ".png")
	done

(*
let main = 
  (* Setup Cairo *)
  let surface = Draw.create_surface width height in
  let ctx = Draw.get_context surface in
  let point1 = {x=200.; y=100.} in
  let point2 = {x=200.; y=50.} in

  (* Set thickness of brush *)
  Cairo.set_line_width ctx 15. ;

  (* Draw out the triangle using absolute coordinates *)
  Cairo.move_to     ctx   200.  100. ;
  Cairo.line_to     ctx   300.  300. ;
  Cairo.rel_line_to ctx (-200.)   0. ;
  Cairo.close_path  ctx ;

  (* Apply the ink *)
  Cairo.stroke ctx ;

  Draw.draw_line ctx point1 point2 2.;

  (* Output a PNG file *)
  Draw.save_to_pngfile surface "triangle.png"
;;

*)
