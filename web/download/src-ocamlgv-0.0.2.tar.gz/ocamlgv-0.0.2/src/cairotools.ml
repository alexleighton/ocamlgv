(** Utility module for drawing using the Cairo library *)

(** Point type. Requires float values for x and y. *)
type point = Point of float*float

(** Color type. Requires three float values for the rgb values. *)
type color = Color of float*float*float

(** Saves the current context and then restores it after applying the
given function. Requires a function that takes unit as a parameter.
@param context The Cairo context to save and restore.
@param f The function to wrap with the save and restore context commands. *)
let wrap_context context f =
	Cairo.save context ;
	f ();
	Cairo.restore context
;;

(** Saves the given surface to the given file in *.png format.
Will overrite a currently existing file.
@param surface The Cairo surface to save.
@param file The string that represents the file to save to. *)
let save_to_pngfile surface file =
	Cairo_png.surface_write_to_file surface file

(** Creates a surface given a width and height.
@param width The width of the surface as an int.
@param height The height of the surface as an int.
@return The Cairo surface. *)
let create_surface width height =
	Cairo.image_surface_create Cairo.FORMAT_ARGB32 ~width ~height

(** Gets the Cairo drawing context from a given surface.
@param surface The Cairo surface. *)
let get_context surface = Cairo.create surface

(** Sets the background color to the given color.
@param context The Cairo context.
@param color The color to set the background. Type: Draw.color. *)
let set_background context color =
	wrap_context context (fun () ->
		match color with Color(r,g,b) ->
		Cairo.set_source_rgb context ~red:r ~green:g ~blue:b ;
		Cairo.paint context ; )
;;

(** Draws a line given a Cairo context, two points, and a width.
@param context The Cairo context.
@param p1 The start point.
@param p2 The end point.
@param width Width of the line as a float. *)
let draw_line context p1 p2 width =
	wrap_context context (fun () ->
		match p1,p2 with
	      Point(x1,y1),Point(x2,y2) ->
			Cairo.set_line_width context  width ;
			Cairo.move_to        context  x1  y1 ;
			Cairo.line_to        context  x2  y2 ;
			Cairo.close_path     context ;
			Cairo.stroke         context )

(** Draws a polygon given a Cairo context, a list of points, and a width.
@param context The Cairo context.
@param pointlist List of points
@param width Width of the lines as a float. *)
let draw_polygon context pointlist width =
	Cairo.set_line_width context  width ;
	let aux = function Point(x1,y1) -> function Point(x2,y2) ->
		Cairo.move_to    context x2 y2 ;
		Cairo.line_to    context x1 y1 ;
		Point(x1,y1)
	in
	match pointlist with
	| []      -> ()
	| p::rest -> (let endp = List.fold_right aux rest p in
					match endp,p with Point(ex,ey),Point(px,py) ->
						Cairo.move_to context px py ;
						Cairo.line_to context ex ey ;
						Cairo.close_path context ; Cairo.stroke context )
;;

(** Draws a rectangle with rounded edges.
 Requires a point at the upper-left corner of the rectangle.
@param context The Cairo context.
@param point The upper-left corner of the rectangle.
@param w The width of the rectangle.
@param h The height of the rectangle.
@param r The radius of the circle sitting at the corners. *)
let rounded_rectangle context point w h r =
	match point with Point(x,y) ->
	let xw = x+.w in
	let yh = y+.h in
	wrap_context context (fun () ->
		Cairo.move_to    context (x+.r) y ;
		Cairo.line_to    context (xw-.r) y ;
		Cairo.curve_to   context xw y xw y xw (y+.r) ;
		Cairo.line_to    context xw (yh-.r) ;
		Cairo.curve_to   context xw yh xw yh (xw-.r) yh ;
		Cairo.line_to    context (x+.r) yh ;
		Cairo.curve_to   context x yh x yh x (yh-.r) ;
		Cairo.line_to    context x (y+.r) ;
		Cairo.curve_to   context x y x y (x+.r) y ;
		Cairo.close_path context ; Cairo.stroke context )
