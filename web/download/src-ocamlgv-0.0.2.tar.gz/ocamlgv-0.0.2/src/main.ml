(* TESTING

(** Main testing file for ocamlgv. *)

open Graph.Pack.Graph;;

(** The file to parse. *)
let file = "test/test.dot";;
let out = "test/testout.dot";;

let output graph = dot_output graph out;;

(** The graph parsed from the dot file 'file'*)
(* let graph = parse_dot_file file;; *)

(** Displays the parsed graph in graphviz *)
let show = display_with_gv;;

(** Main method *)
(* let oldmain = display_with_gv graph ; output graph;; *)

*)
